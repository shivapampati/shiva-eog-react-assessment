import findLocationByLatLng from "./findLocationByLatLng";
import findWeatherbyId from "./findWeatherById";

export default {
  findLocationByLatLng,
  findWeatherbyId
};
