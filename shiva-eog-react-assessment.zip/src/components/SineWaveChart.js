import React, { Component } from "react";
import { connect } from "react-redux";
import * as actions from "../store/actions";
import LinearProgress from "@material-ui/core/LinearProgress";
import { withStyles } from "@material-ui/core/styles";

import ResponsiveContainer from 'recharts/lib/component/ResponsiveContainer';
import LineChart from 'recharts/lib/chart/LineChart';
import Line from 'recharts/lib/cartesian/Line';
import XAxis from 'recharts/lib/cartesian/XAxis';
import YAxis from 'recharts/lib/cartesian/YAxis';
import CartesianGrid from 'recharts/lib/cartesian/CartesianGrid';
import Tooltip from 'recharts/lib/component/Tooltip';
import Legend from 'recharts/lib/component/Legend';


 
import moment from 'moment';

const cardStyles = theme => ({
  root: {
    background: theme.palette.secondary.main
  },
  label: {
    color: theme.palette.primary.main
  }
});


class SineWaveChart extends Component {

  constructor(props) { 
    super(props); 
    this.state = { 
      data: {}
    }; 
  }

  componentDidMount() {
    this.props.onLoad();
  }
  render() {
    
    const {
      loading,
      name,
      weather_state_name,
      temperatureinFahrenheit
    } = this.props;
    if (loading) return <LinearProgress />;
    return (
        <ResponsiveContainer width="99%" height={320}>
            <LineChart data={this.props.data.consolidated_weather}>
                <XAxis dataKey="created" tickFormatter={timeStr => moment(timeStr).format('HH:mm:ss')}/>
                
                <YAxis/>                
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <Tooltip />
                <Legend verticalAlign="top" height={36}/>
                <Line type="monotone" dataKey="the_temp" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
        </ResponsiveContainer>
    );
  }
}

const mapState = (state, ownProps) => {
  const {
    loading,
    name,
    weather_state_name,
    temperatureinFahrenheit,
    data
  } = state.weather;

  return {
    loading,
    name,
    weather_state_name,
    temperatureinFahrenheit,
    data
  };
};

const mapDispatch = dispatch => ({
  onLoad: () =>
    dispatch({
      type: actions.POLL_WEATHER,
      id: 2424766
    })
});

export default connect(
  mapState,
  mapDispatch
)(SineWaveChart);
